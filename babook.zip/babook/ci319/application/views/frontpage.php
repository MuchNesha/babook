<?php
require_once('home/head.php');
require_once('home/header.php');
echo $contents; 
require_once('home/footer.php'); 