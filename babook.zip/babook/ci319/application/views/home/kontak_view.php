<div class="konten">

<!--Map Jalan Romo-->
<iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d3949.424122564336!2d113.72308100000001!3d-8.159953!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sid!4v1428615530278" width="1000" height="300" frameborder="0" style="border:0"></iframe>
<hr>

<!--Alamat kantor-->

<h1>Kantor kami</h1>
<p><strong>Rumah:</strong><br>
  Perumahan Taman Gading Blok EE-19<br>
  Jember, Jawa Timur<br>
  Mobile: 081249735955<br>
  Email: <a href="mailto:yogipoltek@gmail.com">yogipoltek@gmail.com</a>, yogipoltek@yahoo.co.id<br>
  My Blog: <a href="http://yogipoltek.wordpress.com/">www.yogipoltek.wordpres.com</a></p>
<p><strong>Kantor:</strong><br>
  Jl. Mastrip PO BOX 164 – Jember, Jawa Timur<br>
  Phone: 0331-, Fax: 0331-<br>
  Email:<a href="mailto:polije@polije.ac.id">yogis@polije.ac.id</a>, yogis@polije.ac.id<br>
  Website: <a href="http://www.polije.ac.id/">www.polije.ac.id</a></p>

</div>