<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>workshop ci</title>
<link href="<?php echo base_url(); ?>assets/frontpage/css/style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="wrapper">