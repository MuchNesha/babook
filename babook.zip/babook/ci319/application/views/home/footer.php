 <div class="clearfix"></div>
    <footer><a href="http://www.polije.ac.id.com" target="_blank">Website Polieknik Negeri jember</a> | &copy;by yogiswara - 2015</footer></div>
</body>
</html>
