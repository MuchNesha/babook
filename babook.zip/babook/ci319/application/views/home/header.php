 <header>
    	<div id="logo"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/frontpage/images/logopolije.jpeg" width="400" height="400"></a></div>
        <div id="nama"><span class="nama">Praktek Workshop Web</span><br>
        <span class="aipni">Basic Front End Codeigniter</span></div>
  </header>

<nav>
  	<ul>
    	<li><a href="<?php echo base_url(); ?>">Home</a></li>
    	<li><a href="<?php echo base_url(); ?>index.php/fpage/about">About Us</a></li>
        <li><a href="<?php echo base_url(); ?>index.php/fpage/login">Login</a></li>
        <li><a href="<?php echo base_url(); ?>index.php/fpage/kontak">Kontak</a></li>
    </ul>
  </nav>